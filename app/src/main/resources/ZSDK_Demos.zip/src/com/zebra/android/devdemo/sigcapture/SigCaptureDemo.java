/********************************************** 
 * CONFIDENTIAL AND PROPRIETARY 
 *
 * The source code and other information contained herein is the confidential and the exclusive property of
 * ZIH Corp. and is subject to the terms and conditions in your end user license agreement.
 * This source code, and any other information contained herein, shall not be copied, reproduced, published, 
 * displayed or distributed, in whole or in part, in any medium, by any means, for any purpose except as
 * expressly permitted under such license agreement.
 * 
 * Copyright ZIH Corp. 2010
 *
 * ALL RIGHTS RESERVED 
 ***********************************************/
package com.zebra.android.devdemo.sigcapture;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Looper;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.zebra.android.comm.BluetoothPrinterConnection;
import com.zebra.android.comm.TcpPrinterConnection;
import com.zebra.android.comm.ZebraPrinterConnectionException;
import com.zebra.android.devdemo.ConnectionScreen;
import com.zebra.android.devdemo.R;
import com.zebra.android.devdemo.util.SettingsHelper;
import com.zebra.android.devdemo.util.UIHelper;
import com.zebra.android.printer.GraphicsUtil;
import com.zebra.android.printer.ZebraPrinter;
import com.zebra.android.printer.ZebraPrinterFactory;
import com.zebra.android.printer.ZebraPrinterLanguageUnknownException;

public class SigCaptureDemo extends ConnectionScreen {

    private UIHelper helper = new UIHelper(this);
    private SignatureArea signatureArea = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        testButton.setText("Print");

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        signatureArea = new SignatureArea(this);
        LinearLayout connection_screen_layout = (LinearLayout) findViewById(R.id.connection_screen_layout);
        connection_screen_layout.addView(signatureArea, connection_screen_layout.indexOfChild(testButton) + 1, params);
    }

    public void performTest() {
        new Thread(new Runnable() {
            public void run() {
                Looper.prepare();
                doPerformTest();
                Looper.loop();
                Looper.myLooper().quit();
            }
        }).start();

    }

    public void doPerformTest() {
        if (isBluetoothSelected() == false) {
            try {
                int port = Integer.parseInt(getTcpPortNumber());
                zebraPrinterConnection = new TcpPrinterConnection(getTcpAddress(), port);
            } catch (NumberFormatException e) {
                helper.showErrorDialogOnGuiThread("Port number is invalid");
                return;
            }
        } else {
            zebraPrinterConnection = new BluetoothPrinterConnection(getMacAddressFieldText());
        }
        try {
            helper.showLoadingDialog("Printing ...");
            zebraPrinterConnection.open();
            ZebraPrinter printer = ZebraPrinterFactory.getInstance(zebraPrinterConnection);
            GraphicsUtil g = printer.getGraphicsUtil();
            Bitmap image = signatureArea.getBitmap();

            g.printImage(image, 0, 0, image.getWidth(), image.getHeight(), false);

            zebraPrinterConnection.close();
            saveSettings();
        } catch (ZebraPrinterConnectionException e) {
            helper.showErrorDialogOnGuiThread(e.getMessage());
        } catch (ZebraPrinterLanguageUnknownException e) {
            helper.showErrorDialogOnGuiThread(e.getMessage());
        } finally {
            helper.dismissLoadingDialog();
        }
    }

    private void saveSettings() {
        SettingsHelper.saveBluetoothAddress(this, getMacAddressFieldText());
        SettingsHelper.saveIp(this, getTcpAddress());
        SettingsHelper.savePort(this, getTcpPortNumber());
    }
}
/********************************************** 
 * CONFIDENTIAL AND PROPRIETARY 
 *
 * The source code and other information contained herein is the confidential and the exclusive property of
 * ZIH Corp. and is subject to the terms and conditions in your end user license agreement.
 * This source code, and any other information contained herein, shall not be copied, reproduced, published, 
 * displayed or distributed, in whole or in part, in any medium, by any means, for any purpose except as
 * expressly permitted under such license agreement.
 * 
 * Copyright ZIH Corp. 2010
 *
 * ALL RIGHTS RESERVED 
 ***********************************************/
package com.zebra.android.devdemo.discovery;

import java.util.ArrayList;

import android.app.ListActivity;
import android.os.Bundle;
import android.os.Looper;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import com.zebra.android.comm.ZebraPrinterConnectionException;
import com.zebra.android.devdemo.R;
import com.zebra.android.devdemo.util.UIHelper;
import com.zebra.android.discovery.BluetoothDiscoverer;
import com.zebra.android.discovery.DiscoveredPrinter;
import com.zebra.android.discovery.DiscoveredPrinterBluetooth;
import com.zebra.android.discovery.DiscoveryHandler;

public class BluetoothDiscovery extends ListActivity {

    private ArrayList<String> discoveredPrinters = null;
    private ArrayAdapter<String> mArrayAdapter;
    private static DiscoveryHandler btDiscoveryHandler = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
        setContentView(R.layout.discovery_results);

        btDiscoveryHandler = new DiscoveryHandler() {
            public void discoveryError(String message) {
                new UIHelper(BluetoothDiscovery.this).showErrorDialogOnGuiThread(message);
            }

            public void discoveryFinished() {
                runOnUiThread(new Runnable() {
                    public void run() {
                        Toast.makeText(BluetoothDiscovery.this, " Discovered " + discoveredPrinters.size() + " devices", Toast.LENGTH_SHORT).show();
                        setProgressBarIndeterminateVisibility(false);
                    }
                });
            }

            public void foundPrinter(final DiscoveredPrinter printer) {
                runOnUiThread(new Runnable() {
                    public void run() {
                        DiscoveredPrinterBluetooth p = (DiscoveredPrinterBluetooth) printer;
                        discoveredPrinters.add(p.address + " (" + p.friendlyName + ")");
                        mArrayAdapter.notifyDataSetChanged();
                    }
                });
            }
        };

        setProgressBarIndeterminateVisibility(true);
        discoveredPrinters = new ArrayList<String>();
        setupListAdapter();

        new Thread(new Runnable() {
            public void run() {
                Looper.prepare();
                try {
                    BluetoothDiscoverer.findPrinters(BluetoothDiscovery.this, btDiscoveryHandler);
                } catch (ZebraPrinterConnectionException e) {
                    new UIHelper(BluetoothDiscovery.this).showErrorDialogOnGuiThread(e.getMessage());
                } catch (InterruptedException e) {
                    new UIHelper(BluetoothDiscovery.this).showErrorDialogOnGuiThread(e.getMessage());
                } finally {
                    Looper.myLooper().quit();
                }
            }
        }).start();
    }

    private void setupListAdapter() {
        mArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, discoveredPrinters);
        setListAdapter(mArrayAdapter);
    }

}